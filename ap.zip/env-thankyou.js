var dataLayer = dataLayer || [];

// Environment variables
dataLayer.push({
    'brand': 'paololacdao.com',
    'country': 'sg',
    'lang': 'en',
    'pageCategory': 'ecommerce',
    'pageTitle': 'Confirmation',
    'siteType': 'main',
    'websiteVersion': '1.1'
});

