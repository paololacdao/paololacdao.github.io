var dataLayer = dataLayer || [];

// Environment variables
dataLayer.push({
    'brand': 'paololacdao.com',
    'country': 'sg',
    'lang': 'en',
    'pageCategory': 'homepage',
    'pageTitle': 'Home',
    'siteType': 'main',
    'websiteVersion': '1.1'
});

