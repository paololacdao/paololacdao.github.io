var dataLayer = window.dataLayer || [];

document.getElementById('link_homepage').addEventListener('click', function(){
    dataLayer.push({
        'event': 'gaevent',
        'eventCategory': 'interactions',
        'eventAction': 'click',
        'eventLabel': 'link_homepage'
    })
});

document.getElementById('cta').addEventListener('click', function(){
    dataLayer.push({
        'event': 'gaevent',
        'eventCategory': 'interactions',
        'eventAction': 'click',
        'eventLabel': 'cta'
    })
});

document.getElementById('link_confirmation_page').addEventListener('click', function(){
    dataLayer.push({
        'event': 'gaevent',
        'eventCategory': 'interactions',
        'eventAction': 'click',
        'eventLabel': 'link_confirmation_page'
    })
});